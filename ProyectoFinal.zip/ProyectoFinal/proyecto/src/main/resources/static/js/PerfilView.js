document.addEventListener("DOMContentLoaded", function(event) {

    tokenVerification();
    cargarUsuario();
    

    
});

var userinfo;
var nombreUser;
var descargados;

function tokenVerification() {
    //Si no hay token, no podemos entrar en mi perfil
    if (typeof Cookies.get('token') == 'undefined') {
        console.log("Cookie not detected");
        document.location.href="login.html";
    }
}

function cargarUsuario(){

    try {
        const address ='/api/users/miperfil';
        var auth = 'Bearer '+Cookies.get('token');
    	var headers = {
                'Authorization': auth,
             	'Content-Type': 'application/json'

		};
       
        fetch(address, {
            method: 'GET',
           	headers: headers
            })
          .then(response => response.json())
            .then(data => {
                console.log(data);
                userinfo = data;
                nombreUser= data["username"];
                console.log("nombre")
                console.log(nombreUser);
                console.log(typeof nombreUser);
                cargarInfoUsuario();
                cargarDescargados(nombreUser);
                
            });
    } catch (err) {
        console.error(err.message);
        document.location.href="login.html";
    }
    return false;
}

function cargarInfoUsuario(){
    let html= `<h1>${userinfo.username}:</h1>`+               
                    '<p>'+
                        `<strong>Nombre</strong>: ${userinfo.name} <br>`+
                    '</p>'+
                    '<p>'+
                        `<strong>Email</strong>: ${userinfo.mail} <br>`+
                    '</p>'+
                    '<hr>';
    let panel = document.getElementById("datosUser");
    panel.innerHTML = html;
}

function cargarDescargados(nombre){
     try {
        const address ='/api/users/'+nombre+'/descargados';
        console.log(address);
        var auth = 'Bearer '+Cookies.get('token');
        var headers = {
                'Authorization': auth,
                'Content-Type': 'application/json'

        };
       
        fetch(address, {
            method: 'GET',
            headers: headers
            })
          .then(response => response.json())
            .then(data => {
                console.log(data);
                descargados = data;
                cargarInfoDescargados();
                
                
            });
    } catch (err) {
        console.error(err.message);
    }
    return false;
}

function cargarInfoDescargados(){
    let html= '<table class="table">'+ '<tbody>';

    for(let i= 0; i<descargados.length; i++){
                        
        html = html + '<tr>'+'<td>'+i+'</td>' +`<td><strong>Nombre:</strong>${descargados[i].nombre} </td>`+`<td><strong>Descripcion:</strong> ${descargados[i].descripcion} </td>`+ '</tr>'+'<br>';

    }
     html= html + '</tbody>'+'</table>';
    let panel = document.getElementById("cardDescargados");
    panel.innerHTML = html;
}



