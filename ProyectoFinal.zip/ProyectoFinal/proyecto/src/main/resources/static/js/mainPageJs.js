document.addEventListener("DOMContentLoaded", function(event) {
 tokenVerification();
 getNovedades();
 getVendidos();
 

});

function tokenVerification() {
	var elemento = document.getElementById("miperfil");
    if (typeof Cookies.get('token') !== 'undefined') {
        console.log("Cookie detected");
  		elemento.style.display = 'block';
    }else{
  	  elemento.style.display = 'none';
    }
}



function getNovedades(){
     let address = 'http://localhost:8080/api/productos/novedades';
   
        fetch(address,{
            method: 'GET',
            headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json'
                            
                        }
        })
        .then(res => {
              
              return res.json();
        })
        .then(r => {
              console.log(r);
            
              buildContainer(r,"containerNovedades");         
        })
        .catch(e => {
          console.error("Error");
     
        })
     return false;
}

function getVendidos(){
     let address = 'http://localhost:8080/api/productos/topventas';
   
        fetch(address,{
            method: 'GET',
            headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json'
                            
                        }
        })
        .then(res => {
              
              return res.json();
        })
        .then(r => {
              console.log(r);
          
              buildContainer(r,"containerVendidos");         
        })
        .catch(e => {
          console.error("Error");
     
        })
     return false;
}


function getDetalleProducto(i){
  
 let address = 'http://localhost:8080/api/productos/'+i;
 console.log(address);
   
        fetch(address,{
            method: 'GET',
            headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json'
                            
                        }
        })
        .then(res => {
              console.log("Response here");
              return res.json();
        })
        .then(r => {
              console.log(r);
              Cookies.set('producto', r.id);
              document.location.href="producto.html";
     
        })
        .catch(e => {
          console.error("Error");
     
        })
     return false;

}

 
function buildContainer(data,id){
  // console.log(id);
   let panel = document.getElementById(id);
   var html= "";
   for(let i=0; i< data.length; i++){
      html = html + '<div class="col-4">'+
                             '<div class="card border-primary mb-3" style="max-width: 30rem;">'+
                                '<div class="card-header">#'+`${i+1}`+' '+`${data[i].nombre}`+'</div>'+
                                     '<div class="card-body text-primary">'+
                                      '<p><strong>Descripción:</strong></p>'+
                                      `<p>${data[i].descripcion}</p>`+
                                      '<button onclick="getDetalleProducto('+`${data[i].id}`+')">Ver más</button>'+
                                      '</div>'+
                                  '</div>'+
                           '</div>'+
                           '</div>';
  }
  panel.innerHTML = html;
}



function buscarProducto(){
        let address = 'http://localhost:8080/api/productos/buscar?nombre='+document.getElementById("inputBuscar").value;
        console.log(address);
   
        fetch(address,{
            method: 'GET',
            headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json'
                            
                        }
        })
        .then(res => {
              console.log("Response here");
              return res.json();
        })
        .then(r => {
              console.log(r);
             buildContainer(r,"containerBuscar");
             
     
        })
        .catch(e => {
          console.error("Error");
     
        })
     return false;
  }


