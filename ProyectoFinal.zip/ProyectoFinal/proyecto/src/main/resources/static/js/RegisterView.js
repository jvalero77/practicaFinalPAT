  

document.addEventListener("DOMContentLoaded", function(event) {

    tokenVerification();

    var form = document.getElementById("registerForm");
    form.addEventListener("submit", function(e) {
        e.preventDefault();
        return validateForm();
    });
});

function tokenVerification() {

    if (typeof Cookies.get('token') !== 'undefined') {
        console.log("Cookie detected");
        document.location.href="index.html";
    }
}


function validateForm() {
		
			var inputValue1 = document.getElementById("username").value;
			var inputValue2 = document.getElementById("Password").value;
			var inputValue3 = document.getElementById("Name").value;
			var inputValue4 = document.getElementById("Email").value;

			var rep = document.getElementById("PasswordRep").value;
         

			const data = { username: inputValue1, password: inputValue2, name:inputValue3 , mail:inputValue4};
			const address = 'http://localhost:8080/api/register';
            if(inputValue2 == rep){

			fetch(address, {
				method: 'POST',
				headers: {
					'Accept': 'application/json',
					'Content-Type': 'application/json'
				},
				body: JSON.stringify(data)
				})
				.then(response => response.json())
				.then(data => {
					console.log(data);
					alert("Usuario registrado");
				    document.location.href = "index.html";
					
			})
			.catch(e => {
				console.error("Error");
				console.log(e);
				 
			})

	   }else{
	       alert("El password debe coincidir");
	   }
		return false;
}

