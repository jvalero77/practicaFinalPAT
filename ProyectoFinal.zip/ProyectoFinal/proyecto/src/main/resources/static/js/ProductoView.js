const producto = Cookies.get('producto');

document.addEventListener("DOMContentLoaded", function(event) {

    tokenVerification();
    console.log(producto);
    cargarProducto();
    

    
});

var infoproducto;

function tokenVerification() {
    //Si no hay token, no podemos entrar en mi perfil
    if (typeof Cookies.get('token') == 'undefined') {
        console.log("Cookie not detected");
        document.location.href="login.html";
    }
}

function cargarProducto(){

    try {
        const address ='/api/productos/'+producto;
        console.log(address);

        var auth = 'Bearer '+Cookies.get('token');
    	var headers = {
                'Authorization': auth,
             	'Content-Type': 'application/json'

		};
       
        fetch(address, {
            method: 'GET',
           	headers: headers
            })
          .then(response => response.json())
            .then(data => {
                console.log(data);
                infoproducto = data;
                cargarInfoProducto();
                
            });
    } catch (err) {
        console.error(err.message);
    }
    return false;
}

function cargarInfoProducto(){
    let html= `<h1>${infoproducto.nombre}</h1>`+               
                    '<table class="table">'+                         
                         '<tbody>'+
                            '<tr>'+                          
                              '<td>Descripción</td>'+
                              `<td>${infoproducto.descripcion}</td>`+
                            '</tr>'+
                            '<tr>'+
                              
                              '<td>Valoración</td>'+
                              `<td>${infoproducto.valoracion}</td>`+
                            '</tr>'+
                            '<tr>'+
                              
                              '<td>Lenguaje</td>'+
                              `<td>${infoproducto.lenguaje}</td>`+
                            '</tr>'+
                            '<tr>'+
                              
                              '<td>Funcionalidad</td>'+
                              `<td>${infoproducto.funcionalidad}</td>`+
                            '</tr>'+
                            
                         ' </tbody>'+

                        '</table>'+
                         '<div class="row justify-content-md-left">'+
                        '<button type="button" class="btn btn-outline-primary" onclick="descargarProducto()">Descargar</button>'+
                        '</div>';


    let panel = document.getElementById("datosProducto");
    panel.innerHTML = html;
}

function descargarProducto(){
    

     try {
        const address ='/api/users/descargar?id='+producto;
        console.log(address);

        var auth = 'Bearer '+Cookies.get('token');
        var headers = {
                'Authorization': auth,
                'Content-Type': 'application/json'

        };
       
        fetch(address, {
            method: 'POST',
            headers: headers
            })
          .then(response => response.json())
            .then(data => {
                console.log(data);
                 window.alert("Producto descargado");

                
            });
    } catch (err) {
        console.error(err.message);
         window.alert("Ya has descargado este producto");
    }
    return false;

                                
}




