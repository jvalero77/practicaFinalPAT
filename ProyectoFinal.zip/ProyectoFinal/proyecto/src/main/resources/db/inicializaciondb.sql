DROP TABLE IF EXISTS USUARIOS;

CREATE TABLE USUARIOS(
	USERNAME VARCHAR(15) PRIMARY KEY,
	NAME VARCHAR(40) NOT NULL,
	PASSWORD VARCHAR(15) NOT NULL,
	MAIL VARCHAR(40) NOT NULL
);

DROP TABLE IF EXISTS PRODUCTOS;

CREATE TABLE PRODUCTOS(
	ID INTEGER IDENTITY PRIMARY KEY,
	DESCRIPCION VARCHAR(100) NOT NULL,
	VALORACION DECIMAL(3,2) NOT NULL,
	FECHA DATE NOT NULL,
	NDESCARGAS INTEGER NOT NULL,
	NVALORACIONES INTEGER NOT NULL,
	LENGUAJE VARCHAR(50) NOT NULL,
	NOMBRE VARCHAR(50) NOT NULL,
	CODIGO VARCHAR(50) NOT NULL,
	FUNCIONALIDAD VARCHAR(50)
	
);

DROP TABLE IF EXISTS DESCARGADOS;

CREATE TABLE DESCARGADOS(
    USERNAME VARCHAR(15) ,
	ID INTEGER,
	PRIMARY KEY(USERNAME,ID),
	CONSTRAINT USERNAME_DESC_FK 
     FOREIGN KEY (USERNAME) 
     REFERENCES USUARIOS (USERNAME),
  CONSTRAINT ID_DESC_FK 
     FOREIGN KEY (ID) 
     REFERENCES PRODUCTOS (ID)
	
);

INSERT INTO PRODUCTOS(descripcion,valoracion,fecha,ndescargas,nvaloraciones,lenguaje,nombre, codigo,funcionalidad) VALUES
('Para ver si te están robando WiFi', 3, '2021-9-12', 140,31,'algo','Fing','codigo1','Internet'),
('Para recibir una alerta si alguien se conecta a tu WiFi', 3, '2021-9-11', 130,31,'algo','WiFi Guard','codigo1','Internet'),
('Para ver, editar y guardar PDFs', 3, '2021-9-10', 120,31,'algo','Foxit Reader','codigo1','Documentos'),
('Para editar documentos', 3, '2021-9-9', 31231,31,'algo','LibreOffice','codigo1','Documentos'),
('Para editar fotografías', 3, '2021-9-8', 333,31,'algo','GIMP','codigo1','Fotografia'),
('Para editar vídeos', 3, '2021-9-7', 31231,31,'algo','Lightworks','codigo1','Video/Audio'),
('El reproductor de vídeo imprescindible', 3, '2020-9-12', 30,31,'algo','VLC Media Player','codigo1','Video/Audio'),
('Para extraer archivos comprimidos', 3, '2020-9-12', 30,31,'algo','7zip','codigo1','Comprimir'),
('Para hacer capturas de la pantalla', 3, '2020-9-12', 30,31,'algo','PicPick','codigo1','Screenshot'),
('Para tener controlado el rendimiento de tu PC', 3, '2020-9-12', 30,31,'algo','Rainmeter','codigo1','Optimizacion'),
('Un buen antivirus gratis', 3, '2020-9-12', 30,31,'algo','Avast','codigo1','Antivirus'),
('Para que tus fotos estén siempre en la nube', 3, '2020-9-12', 30,31,'algo','Google Fotos','codigo1','Cloud'),
('Para borrar archivos de forma segura', 3, '2020-9-12', 30,31,'algo','Eraser','codigo1','Archivos'),
('Para tener copias de seguridad', 3, '2020-9-12', 30,31,'algo','EaseUS','codigo1','Cloud');


INSERT INTO USUARIOS(username, name, password, mail) VALUES
('Usuario1','Nombre1','pass1','usuario1@mail.com'),
('Usuario2','Nombre2','pass2','usuario2@mail.com'),
('Usuario3','Nombre3','pass3','usuario3@mail.com'),
('Usuario4','Nombre4','pass4','usuario4@mail.com'),
('Usuario5','Nombre5','pass5','usuario5@mail.com'),
('Usuario6','Nombre6','pass6','usuario6@mail.com'),
('Usuario7','Nombre7','pass7','usuario7@mail.com'),
('Usuario8','Nombre8','pass8','usuario8@mail.com');

INSERT INTO DESCARGADOS(username,id) VALUES
('Usuario1',1),
('Usuario1',2);
