package com.finalproject.proyecto.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Table("USUARIOS")
@AllArgsConstructor
@NoArgsConstructor
public class Usuario {

	@Id
	@Column("USERNAME")
	private String username;
	@Column("NAME")
	private String name;
	@Column("PASSWORD")
	private String password;
	@Column("MAIL")
	private String mail;
	
	
	
	
}
