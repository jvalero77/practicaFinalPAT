package com.finalproject.proyecto.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.finalproject.proyecto.model.Producto;
import com.finalproject.proyecto.model.ProductosDescargados;
import com.finalproject.proyecto.model.Usuario;
import com.finalproject.proyecto.service.impl.UsuariosServiceImpl;

@RestController
@RequestMapping("api/users")
public class UserController {
	@Autowired
	UsuariosServiceImpl usuariosService;
	
	@GetMapping("/miperfil")
	public ResponseEntity<Usuario> getUsuario()throws Exception{
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String currentPrincipalName = authentication.getName();
		Usuario user= usuariosService.getInfoUsuario(currentPrincipalName);
		return new ResponseEntity<Usuario>(user, HttpStatus.OK);
	}
	
	@GetMapping
	public ResponseEntity<List<Usuario>> getAllUsuarios(){
	
		final List<Usuario> usuarios= usuariosService.getTodosUsuarios();
		return new ResponseEntity<List<Usuario>>(usuarios, HttpStatus.OK);
		
	}
	
	
	
	@DeleteMapping("/{username}")
	public ResponseEntity<String> deleteUsuario(@PathVariable String username){
		usuariosService.deleteUsuario(username);
		return new ResponseEntity<String>("OK", HttpStatus.OK);
	}
	
	@GetMapping("/{username}/subidos")
	public ResponseEntity<List<Producto>> getSubidos(@PathVariable String username){
		final List<Producto> productos= usuariosService.getSubidos(username);
		return new ResponseEntity<List<Producto>>(productos, HttpStatus.OK);
	}
	
	@GetMapping("/{username}/descargados")
	public ResponseEntity<List<Producto>> getDescargados(@PathVariable String username){
		final List<Producto> productos= usuariosService.getDescargados(username);
		return new ResponseEntity<List<Producto>>(productos, HttpStatus.OK);
	}
	
	@PostMapping("/descargar")
	public ResponseEntity<Integer> descargarProducto(@RequestParam("id") int id){
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String currentPrincipalName = authentication.getName();
		Integer p= usuariosService.descargarProducto(currentPrincipalName, id);
		return new ResponseEntity<Integer>(p, HttpStatus.OK);
	}
	
	
	
	
	
}
