package com.finalproject.proyecto.model;

import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

@Table("SUBIDOS")
public class ProductosSubidos {
	@Column("USERNAME")
	private String username;
	@Column("ID")
	private int idproducto;
	
}
