package com.finalproject.proyecto.service.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.finalproject.proyecto.model.Producto;
import com.finalproject.proyecto.model.ProductosDescargados;
import com.finalproject.proyecto.model.ProductosSubidos;
import com.finalproject.proyecto.model.Usuario;
import com.finalproject.proyecto.repository.DescargadosRepository;
import com.finalproject.proyecto.repository.ProductosRepository;
import com.finalproject.proyecto.repository.SubidosRepository;
import com.finalproject.proyecto.repository.UsuariosRepository;
import com.finalproject.proyecto.service.UsuariosService;

@Service
public class UsuariosServiceImpl implements UsuariosService {

	@Autowired
	private UsuariosRepository usuariosRepository;
	@Autowired
	private SubidosRepository subidosRepository;
	@Autowired 
	private DescargadosRepository descargadosRepository;
	@Autowired
	private ProductosRepository productosRepository;
	
	@Override
	public Usuario getInfoUsuario(String username) {
		Usuario user = usuariosRepository.getInformacionUsuario(username);
		return user;
		
	}
	
	@Override
	public Usuario createUsuario(Usuario user) {
		Usuario u= usuariosRepository.save(user);
		return u;
	}
	@Override
	public void deleteUsuario(String username) {
		usuariosRepository.deleteById(username);
	}
	
	@Override
	public List<Producto> getSubidos(String username) {
		List<ProductosSubidos> subidos=subidosRepository.findbyUser(username);
		ArrayList<Producto> productos= new ArrayList<>();
		subidos.forEach((ps)->{
			productos.add(productosRepository.findbyId(ps.getIdproducto()));
		});
		
		return productos;
		
	}
	
	@Override
	public List<Producto> getDescargados(String username) {
		List<ProductosDescargados> descargados= descargadosRepository.findbyUser(username);
		ArrayList<Producto> productos= new ArrayList<>();
		descargados.forEach((pd)->{
			productos.add(productosRepository.findbyId(pd.getIdproducto()));
		});
		
		return productos;
	}

	
	@Override
	public List<Usuario> getTodosUsuarios() {
		final Iterable<Usuario> usuarios = usuariosRepository.findAll();
		final ArrayList<Usuario> usuariosList = new ArrayList<>();
		final Iterator<Usuario> it = usuarios.iterator();
		while (it.hasNext()) {
			final Usuario u = it.next();
			usuariosList.add(u);
		}
		return usuariosList;
	}

	@Override
	public int descargarProducto(String username, int id) {
		return descargadosRepository.descargarProducto(username, id);
	}

	@Override
	public int registrarUsuario(Usuario user) {
		return usuariosRepository.registrarUsuario(user.getUsername(),user.getPassword(),user.getName(),user.getMail());
	}

}
