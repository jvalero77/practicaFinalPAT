package com.finalproject.proyecto.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.finalproject.proyecto.model.Producto;
import com.finalproject.proyecto.service.impl.ProductosServiceImpl;

@RestController
@RequestMapping("api/productos")
public class ProductController {
	@Autowired
	private ProductosServiceImpl productosService;
	
	@GetMapping("/{id}")
	public ResponseEntity<Producto> getProducto(@PathVariable int id){
		System.out.println("hola");
		Producto producto = productosService.buscarProducto(id);
		return new ResponseEntity<Producto>(producto, HttpStatus.OK);
	}
	
	
	@GetMapping
	public ResponseEntity<List<Producto>> getAllProductos(){
		final List<Producto> productos= productosService.getTodosProductos();
		return new ResponseEntity<List<Producto>>(productos, HttpStatus.OK);
	}
	
	@GetMapping("/buscar")
	public ResponseEntity<List<Producto>> buscarProducto(@RequestParam("nombre") String nombre){
	
		
		final List<Producto> productos= productosService.buscarProducto(nombre);
		
		return new ResponseEntity<List<Producto>>(productos, HttpStatus.OK);
	}
	
	@PostMapping("/")
	public ResponseEntity<Producto> createProducto(@RequestBody Producto producto){
		Producto p= productosService.crearProducto(producto);
		return new ResponseEntity<Producto>(p, HttpStatus.CREATED);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteProducto(@PathVariable int id){
		productosService.borrarProducto(id);
		return new ResponseEntity<String>("OK", HttpStatus.OK);
	}
	
	@GetMapping("/novedades")
	public ResponseEntity<List<Producto>> getNovedades(){
		final List<Producto> productos= productosService.getNuevos();
		return new ResponseEntity<List<Producto>>(productos, HttpStatus.OK);
	}
	@GetMapping("/topventas")
	public ResponseEntity<List<Producto>> getMasVendidos(){
		final List<Producto> productos= productosService.getMasVendidos();
		return new ResponseEntity<List<Producto>>(productos, HttpStatus.OK);
	}
	
	
}
