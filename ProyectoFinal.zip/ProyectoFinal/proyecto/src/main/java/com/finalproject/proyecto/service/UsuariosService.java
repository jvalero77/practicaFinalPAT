package com.finalproject.proyecto.service;

import java.util.List;

import com.finalproject.proyecto.model.Producto;
import com.finalproject.proyecto.model.ProductosDescargados;
import com.finalproject.proyecto.model.Usuario;

public interface UsuariosService {

	public Usuario getInfoUsuario(String username);
	public Usuario createUsuario(Usuario user);
	public void deleteUsuario(String username);
	public List<Producto> getSubidos(String username);
	public List<Producto> getDescargados(String username);
	public List<Usuario> getTodosUsuarios();
	public int descargarProducto(String username, int id);
	public int registrarUsuario(Usuario user);
}
