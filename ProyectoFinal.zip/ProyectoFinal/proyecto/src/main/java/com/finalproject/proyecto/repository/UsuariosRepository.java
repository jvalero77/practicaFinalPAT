package com.finalproject.proyecto.repository;

import org.springframework.data.jdbc.repository.query.Modifying;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.finalproject.proyecto.model.Usuario;

@Repository
public interface UsuariosRepository extends CrudRepository<Usuario, String>{
	
	@Query("SELECT * FROM USUARIOS WHERE USERNAME= :username")
	public Usuario getInformacionUsuario(@Param("username") String username);
	
	@Query("SELECT TOP 1 * FROM USUARIOS WHERE USERNAME= :username")
	public Usuario getUserDetailByUserName(@Param("username") String username);
	
	@Transactional
	@Query("INSERT INTO USUARIOS (USERNAME,PASSWORD,NAME,MAIL) VALUES (:username, :password, :name, :mail)")
	@Modifying
	public int registrarUsuario(@Param("username") String username,@Param("password") String password,@Param("name") String name,@Param("mail") String mail);
}
