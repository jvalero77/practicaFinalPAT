package com.finalproject.proyecto.repository;

import java.util.List;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.finalproject.proyecto.model.Producto;

@Repository
public interface ProductosRepository extends CrudRepository<Producto, Integer>{

	@Query("SELECT * FROM PRODUCTOS WHERE NOMBRE=:nombre")
	public List<Producto> findbyNombre(@Param("nombre") String nombre);
	
	@Query("SELECT * FROM PRODUCTOS WHERE ID=:id")
	public Producto findbyId(@Param("id") int id);
	
	@Query("SELECT * FROM PRODUCTOS WHERE NOMBRE LIKE :nombre")
	public List<Producto> buscarProducto(@Param("nombre") String nombre);
	
	@Query("SELECT TOP 6 * FROM PRODUCTOS ORDER BY FECHA DESC")
	public List<Producto> findNovedades();
	
	@Query("SELECT TOP 6 * FROM PRODUCTOS ORDER BY NDESCARGAS DESC")
	public List<Producto> findBestSellers();
	
}

