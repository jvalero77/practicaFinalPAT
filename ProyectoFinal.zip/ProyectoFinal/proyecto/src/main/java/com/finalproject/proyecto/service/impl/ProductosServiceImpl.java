package com.finalproject.proyecto.service.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.finalproject.proyecto.model.Producto;
import com.finalproject.proyecto.repository.ProductosRepository;
import com.finalproject.proyecto.service.ProductosService;



@Service
public class ProductosServiceImpl implements ProductosService{
	@Autowired 
	ProductosRepository productosRepository;
	
	@Override
	public Producto buscarProducto(int id) { 
                  final Producto p =  productosRepository.findbyId(id);
                  return p;
	}
	
	
	@Override
	public List<Producto> getTodosProductos() {
		final Iterable<Producto> productos = productosRepository.findAll();
		final ArrayList<Producto> productosList = new ArrayList<>();
		final Iterator<Producto> it = productos.iterator();
		while (it.hasNext()) {
			final Producto p = it.next();
			productosList.add(p);
		}
		return productosList;
	}
	
	@Override
	public Producto crearProducto(Producto producto) {
		final Producto p = productosRepository.save(producto);
		return p;
	}


	@Override
	public void borrarProducto(int id) {
		productosRepository.deleteById(id);
		
	}
	@Override
	public List<Producto> getNuevos() {
		return productosRepository.findNovedades();
	}
	@Override
	public List<Producto> getMasVendidos() {
		return productosRepository.findBestSellers();
	}


	@Override
	public List<Producto> buscarProducto(String nombre) {
		
		nombre = '%'+nombre +'%';
		List<Producto> p  =productosRepository.buscarProducto(nombre);
		
		return p;
	}
	

}
