package com.finalproject.proyecto.repository;

import java.util.List;

import org.springframework.data.jdbc.repository.query.Modifying;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.finalproject.proyecto.model.Producto;
import com.finalproject.proyecto.model.ProductosDescargados;

public interface DescargadosRepository  extends CrudRepository<ProductosDescargados, String>{
	
	@Query("SELECT * FROM DESCARGADOS WHERE USERNAME=:username")
	public List<ProductosDescargados> findbyUser(@Param("username")String username);
	
	@Transactional
	@Query("INSERT INTO DESCARGADOS (USERNAME,ID) VALUES (:username,:id)")
	@Modifying
	public int descargarProducto(@Param("username")String username, @Param("id")int id);
}
