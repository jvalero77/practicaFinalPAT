package com.finalproject.proyecto.model;





import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Table("PRODUCTOS")
public class Producto{
	@Id
	@Column("ID")
	private int id;
	@Column("DESCRIPCION")
	private String descripcion;
	@Column("VALORACION")
	private double valoracion;
	@Column("FECHA")
	private Date fecha;
	@Column("NDESCARGAS")
	private int ndescargas;
	@Column("NVALORACIONES")
	private int nvaloraciones;
	@Column("LENGUAJE")
	private String lenguaje;
	@Column("NOMBRE")
	private String nombre;
	@Column("CODIGO")
	private String codigo;
	@Column("FUNCIONALIDAD")
	private String funcionalidad;
	

}
