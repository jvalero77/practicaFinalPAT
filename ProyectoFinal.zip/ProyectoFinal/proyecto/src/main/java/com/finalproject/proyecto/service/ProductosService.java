package com.finalproject.proyecto.service;

import java.util.List;

import com.finalproject.proyecto.model.Producto;

public interface ProductosService {
	
	public Producto buscarProducto(int id);
	public List<Producto> getTodosProductos();
	public Producto crearProducto(Producto producto);
	public void borrarProducto(int id);
	public List<Producto> getNuevos();
	public List<Producto> getMasVendidos();
	public List<Producto> buscarProducto(String nombre);

}
